import machine
from time import sleep
import sys
import BME280

import gc
gc.collect()    # Limpiar posible basura en memoria

sda = machine.Pin(21)  # GP_21
scl = machine.Pin(22)  # GP_22

i2c = machine.I2C(0, sda=sda, scl=scl, freq=100000)
led = machine.Pin(5,machine.Pin.OUT)
led.off()

# ************************
# Configure the ESP32 wifi
# as STAtion mode.
import network
import utime
#import wifi_credentials
#sta_if = network.WLAN(network.STA_IF)
sta = network.WLAN(network.STA_IF)
if not sta.isconnected():
  print('Conectando con la red WiFi...')
  sta.active(True)
  #sta.connect('your wifi ssid', 'your wifi password')
  sta.connect('RED1', 'boricua')
  #sta.connect(wifi_credentials.ssid, wifi_credentials.password)
  while not sta.isconnected():
    pass
print("Ip asignada:",sta.ifconfig()[0])

import socket
#------------ Crea un socket TCP (SOCK_STREAM) ---------------
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('',80)) # Desde cualquier IP se escucha en el puerto 80
s.listen(5)     # Reconoce solo 5 socket a la vez


# *********************************
# Esta función es la encargada de
# crear la página web
#**********************************
def web_page():
    html_page = """
<!DOCTYPE html>  
 <html>  
  <head>  
  <meta name='viewport' content='width=device-width, initial-scale=1.0'/>  
  <script>   
   var AjaxSolicitud = new XMLHttpRequest();  
   
   function CargarAjax(ajaxURL)  
   {  
    AjaxSolicitud.open('GET',ajaxURL,true);  
    AjaxSolicitud.onreadystatechange = function()  
    {  
     if(AjaxSolicitud.readyState == 4 && AjaxSolicitud.status==200)  
     {  
      var AjaxRespuesta = AjaxSolicitud.responseText;  
      var tmpArray = AjaxRespuesta.split("|");  
      document.getElementById('temp').innerHTML = tmpArray[0];  
      document.getElementById('hum').innerHTML = tmpArray[1];
      document.getElementById('pres').innerHTML = tmpArray[2];
     }  
    }  
    AjaxSolicitud.send();  
   }  
     
   function leerBME280()   
   {   
     CargarAjax('leer_sensor');   
   }  
     
   setInterval(leerBME280, 2000);  
    
  </script>   
  <title>Micropython & ESP32</title>
  </head>    
  <body style=background:#F5DEB3>
  <title>Micropython & ESP32</title>
   <center>  
   <div id='main'>  
    <h1>MicroPython con ESP32 + Ajax</h1>  
    <h2>Web server con ESP32</h2>  
    <div id='content'>   
     <p>Temperatura: <strong><span id='temp'>--.-</span></strong></p>  
     <p>Humedad: <strong><span id='hum'>--.-</span></strong></p>
     <p>Presion: <strong><span id='pres'>--.-</span></strong></p> 
    </div>  
   </div>
    <br>
      <hr Size=7 noshade/><H4><font color='black'>by. Firtec Argentina </H4> 
   </center>  
  </body>  
 </html>
"""
    return html_page

while True:
    if gc.mem_free() < 102000:  # Si la memoria es menos de 102000
      gc.collect()              # Limpiar basura 
    bme = BME280.BME280(i2c=i2c)
    temp = bme.temperature
    hum = bme.humidity
    pres = bme.pressure
    #print('Temperatura: ', temp)
    #print('Humedad: ', hum)
    #print('Presion: ', pres)
    conexion, addr = s.accept()
    mensaje = conexion.recv(1024)
    mensaje = str(mensaje)
    consulta = mensaje.find('/leer_sensor')
    if consulta == 6:
        temp = bme.temperature
        hum = bme.humidity
        pres = bme.pressure
        respuesta = temp + "|"+ hum + "|"+ pres
        led.value(not led.value())
    else:
       respuesta = web_page()    
  
    conexion.send('HTTP/1.1 200 OK\n')
    conexion.send('Content-Type: text/html\n')
    conexion.send('Connection: close\n\n')
    conexion.sendall(respuesta)
    conexion.close()
