
from machine import I2C, Pin
import DS3231
import time
import lcd_44780  # Importa el driver para la pantalla

sda = machine.Pin(0)  # GP_0
scl = machine.Pin(1)  # GP_1

i2c = machine.I2C(0, sda=sda, scl=scl, freq=100000)
ds = DS3231.DS3231(i2c)
ds.Hour(24)
ds.Time()
ds.DateTime([2021,5,13,1,17,24,0])

def ISR_rtc(p):
        global display
        temp = (ds.Temperature())
        b = ds.Date()
        a = ds.Time()
        datos = "%.01f" % temp
        display.set_line(0)
        display.set_string("Temperatura:" + datos)
        fecha = ("Fecha: {:02d}/{:02d}/{}".format(b[2],b[1],b[0]))
        display.set_line(1)
        display.set_string(fecha)
        hora = ("Hora: {:02d}:{:02d}:{:02d}".format(a[0],a[1],a[2]))
        display.set_line(2)
        display.set_string(hora)

rtc = Pin(16, Pin.IN, Pin.PULL_UP)
rtc.irq(trigger=Pin.IRQ_RISING, handler= ISR_rtc)

def main():
    # Pines usados por la pantalla LCD
    display_pines = [2, 3, 4, 5, 6, 7]
    # Nombre de los pines del LCD (NO CAMBIARLOS)
    nombre_pines = ['RS','E','D4','D5','D6','D7']
    caracteres = 20  # Cantidad de caracteres del LCD en uso
    # Pasa los datos al modulo de control para la pantalla
    global display
    display = lcd_44780.LCD(display_pines,nombre_pines, caracteres )
    display.init() # Configura el inicio de la pantalla
    #display.set_line(0)
    #display.set_string("     RTC DS3231")
    display.set_line(3)
    display.set_string("   www.firtec.ar")
    while(1):
        """
        temp = (ds.Temperature())
        b = ds.Date()
        a = ds.Time()
        datos = "%.01f" % temp
        display.set_line(0)
        display.set_string("Temperatura:" + datos)
        fecha = ("Fecha: {:02d}/{:02d}/{}".format(b[2],b[1],b[0]))
        display.set_line(1)
        display.set_string(fecha)
        hora = ("Hora: {:02d}:{:02d}:{:02d}".format(a[0],a[1],a[2]))
        display.set_line(2)
        display.set_string(hora)
        
        time.sleep_ms(800)
        """
if __name__ == '__main__':
    main()