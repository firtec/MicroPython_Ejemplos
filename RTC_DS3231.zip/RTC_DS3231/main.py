
from machine import I2C, Pin
import DS3231
import time
sda = machine.Pin(0)  # GP_0
scl = machine.Pin(1)  # GP_1

i2c = machine.I2C(0, sda=sda, scl=scl, freq=100000)
ds = DS3231.DS3231(i2c)

ds.Hour(24)

ds.Time()

ds.DateTime([2021,5,13,1,17,24,0])
a = []
while(1):  
    print(ds.Temperature())
    b = ds.Date()
    a = ds.Time()
    print(b[2],b[1],b[0])
    print(a[0],a[1],a[2])
    time.sleep_ms(800)