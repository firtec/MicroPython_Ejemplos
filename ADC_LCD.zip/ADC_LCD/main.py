#****************************************************************************************
# Descripción : Lee el canal analógico 0 (GP_26) y muestra los datos en pantalla LCD
# Target :      Raspberry Pi PICO + Hitachi 44780
# ToolChain :   MicroPython
# www.firtec.com.ar
#***************************************************************************************
from machine import Pin, ADC
from time import sleep
#from machine import Pin, Timer
import utime
import lcd_44780  # Importa el driver para la pantalla


def main():
    # Pines usados por la pantalla LCD
    display_pines = [2, 3, 4, 5, 6, 7]
    # Nombre de los pines del LCD (NO CAMBIARLOS)
    nombre_pines = ['RS','E','D4','D5','D6','D7']
    caracteres = 20  # Cantidad de caracteres del LCD en uso
    # Pasa los datos al modulo de control para la pantalla
    display = lcd_44780.LCD(display_pines,nombre_pines, caracteres )
    display.init() # Configura el inicio de la pantalla
    
    display.set_line(0)
    display.set_string("--------------------")
    display.set_line(1)
    display.set_string("--------------------")
    display.set_line(2)
    display.set_string("--------------------")
    display.set_line(3)
    display.set_string("--------------------")
    
    potenciometro = ADC(0) # Canal ADC en pin 26
    factor_16 = 3.3 / (65535)  
    
    while True:    
        bits_16 = potenciometro.read_u16();
        volts_16 = bits_16 * factor_16
        datos = "%.02f" % (volts_16)
        display.set_line(1)
        display.set_string("Voltios:" + datos)
        display.set_line(3)
        display.set_string("   www.firtec.ar")
        sleep(1)
if __name__ == '__main__':
    main()