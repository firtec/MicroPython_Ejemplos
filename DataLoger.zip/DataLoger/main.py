from machine import I2C, Pin
import DS3231
import time
from machine import SPI
import machine, onewire, ds18x20
import sdcard
import os


def ISR_rtc(p):
    global retardo
    retardo += 1

led = Pin(25, Pin.OUT)
led.value(0) 
ds_pin = machine.Pin(16) # GPIO_16 Pin 21 en la placa
ds_sensor = ds18x20.DS18X20(onewire.OneWire(ds_pin))
 
roms = ds_sensor.scan()   
sda = machine.Pin(0)  # GP_0
scl = machine.Pin(1)  # GP_1

sd_spi = SPI(1, sck = Pin(10, Pin.OUT), mosi = Pin(11, Pin.OUT),miso = Pin(12, Pin.OUT))
sd = sdcard.SDCard(sd_spi, Pin(15, Pin.OUT))
vfs = os.VfsFat(sd)
i2c = machine.I2C(0, sda=sda, scl=scl, freq=100000)
ds = DS3231.DS3231(i2c)

ds.Hour()
ds.Time()

ds.DateTime([2021,6,24,1,17,19,0])  # Ajuste de la hora a valores iniciales

rtc = Pin(17, Pin.IN, Pin.PULL_UP)
rtc.irq(trigger=Pin.IRQ_RISING, handler= ISR_rtc)
retardo = 59
dato_viejo = 0

while(1):  
    ds_sensor.convert_temp()
    time.sleep_ms(750)
    led.toggle()
    if retardo == 60:   # Tiempo de espera entre lecturas
        for rom in roms:
            Va = ds_sensor.read_temp(rom)  
            temperatura = "%.01f" % Va   # Formato ASCII
            if (dato_viejo != temperatura):
                dato_viejo = temperatura    
                #print(temperatura)
                
                ext = ".csv"
                b = ds.Date()
                dia = "%.d" % (b[2])
                mes = "%.d" % (b[1])
                year = "%.d" % (b[0])
                fecha = "_".join((dia,mes,year))
                archivo = "/fc/" + fecha + ext
                a = ds.Time()
                hora = "%.d" % (a[0])
                minutos = "%.d" % (a[1])
                segundos = "%.d" % (a[2])
                hora = ":".join((hora,minutos,segundos))
                historial = ",".join((hora,temperatura))
                historial = historial + "\n"
                os.mount(vfs, "/fc")
                with open(archivo, "a") as f:
                    n = f.write(historial)
                os.umount("/fc")
        #print(retardo)
        retardo = 0
