
from machine import Pin, PWM, ADC
pin = machine.Pin(15)
pwm = machine.PWM(pin)
pwm.freq(50)
potentiometer = machine.ADC(26)

conversion_factor = 0.10681

while True:
    pot = potentiometer.read_u16()
    print(pot)
    duty = pot * conversion_factor # 
    duty = round(duty) # Con round()obtenemos valores enteros para el PWM
    pwm.duty_u16(duty) # Señal de control puesta en el pin GP_16 
   
