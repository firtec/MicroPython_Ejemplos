# Display Image & text on I2C driven SH1106 OLED display 
from machine import Pin, I2C
from sh1106 import SH1106_I2C
import framebuf
import rp2
import time

WIDTH  = 128                                            # oled display width
HEIGHT = 64 # oled display height

i2c = I2C(0, scl=Pin(9), sda=Pin(8), freq=400000)       # Init I2C using pins GP8 & GP9 (default I2C0 pins)
oled = SH1106_I2C(WIDTH, HEIGHT, i2c)                  # Init oled display
time.sleep(3)
oled.fill(0)

def horiz(l,t,r,c):  # left, top, right colour
    n = r-l+1        # Horizontal line
    for i in range(n):
        oled.pixel(l + i, t , c)

def vert(l,t,b,c):   # left, top, bottom, colour
    n = b-t+1        # Vertical line
    for i in range(n):
        oled.pixel(l, t+i, c)
def marco():
    horiz(0,0,127,1)
    vert(0,0,63,1)
    vert(127,0,63,1)
    horiz(0,63,127,1)
    oled.text("www.firtec.ar",12,53)

#---------------------------------------------------

@rp2.asm_pio(set_init=(rp2.PIO.OUT_LOW,rp2.PIO.OUT_LOW),
         autopush=True, in_shiftdir=rp2.PIO.SHIFT_LEFT)
def dht22():
    wrap_target()
    #label("again")
    pull(block)
    set(pins, 0)
    mov(x, osr)
    label("bucle")
    jmp(x_dec, "bucle")
    set(pindirs, 0)
    wait(1, pin, 0)
    wait(0, pin, 0)
    wait(1, pin, 0)
    wait(0, pin, 0)
    set(y, 31)
    label("bits")
    wait(1, pin, 0) [25]
    in_(pins, 1)
    wait(0, pin, 0)
    jmp(y_dec, "bits")
      
    set(y, 7)
    label("check")
    wait(1, pin, 0)[25]
    set(pins,2)
    set(pins,0)
    in_(pins, 1)
    wait(0, pin, 0)
    jmp(y_dec, "check")
    push(block)
    wrap()

class DHT22():
    def __init__(self, gpio):
        self.sm = rp2.StateMachine(0, dht22, freq=490196,
           in_base=Pin(gpio), set_base=Pin(gpio), jmp_pin=Pin(gpio))
        self.sm.active(1)
    def getReading(self):
        self.sm.put(500)
        data=0
        data = self.sm.get()
        byte1 = (data >> 24 & 0xFF)
        byte2 = (data >> 16 & 0xFF)
        byte3 = (data >> 8 & 0xFF)
        byte4 = (data & 0xFF)
        checksum = self.sm.get() & 0xFF
        self.checksum = (checksum == (byte1+byte2+byte3+byte4) & 0xFF)
        self.humidity = ((byte1 << 8) | byte2) / 10.0
        neg = byte3 & 0x80
        byte3 = byte3 & 0x7F
        self.temperature = (byte3 << 8 | byte4) / 10.0
        if neg > 0:
            self.temperature = -self.temperature

oled.show()
#borrar = "                                                                     "

while (1):
    oled.fill(0)
    marco()
    dht = DHT22(2)
    dht.getReading()
    humedad = "Humedad:%.01f " % (dht.humidity)
    temperatura = "Temp: %.01f " % (dht.temperature)
    oled.text(temperatura,5,5)
    oled.text(humedad,5,15)
    oled.show()
    time.sleep(2)