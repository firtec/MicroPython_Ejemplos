#****************************************************************************************
# Descripción : Ejemplo de uso para una pantalla Hitachi 44780 + Sensor BME280
# Target :      Raspberry Pi PICO
# ToolChain :   MicroPython
# www.firtec.com.ar
#***************************************************************************************
from machine import Pin, I2C
from time import sleep
#from machine import Pin, Timer
import utime
import lcd_44780  # Importa el driver para la pantalla
import BME280     # Importa el driver para BME280

# Define los pines I2C. 
sda = machine.Pin(0)  # GP_0
scl = machine.Pin(1)  # GP_1

i2c = machine.I2C(0, sda=sda, scl=scl, freq=100000)

def main():
    # Pines usados por la pantalla LCD
    display_pines = [2, 3, 4, 5, 6, 7]
    # Nombre de los pines del LCD (NO CAMBIARLOS)
    nombre_pines = ['RS','E','D4','D5','D6','D7']
    caracteres = 20  # Cantidad de caracteres del LCD en uso
    # Pasa los datos al modulo de control para la pantalla
    display = lcd_44780.LCD(display_pines,nombre_pines, caracteres )
    display.init() # Configura el inicio de la pantalla
    
    display.set_line(0)
    display.set_string("--------------------")
    display.set_line(1)
    display.set_string("--------------------")
    display.set_line(2)
    display.set_string("--------------------")
    display.set_line(3)
    display.set_string("--------------------")
    while True:    
        bme = BME280.BME280(i2c=i2c)
        temp = bme.temperature
        hum = bme.humidity
        pres = bme.pressure
        # uncomment for temperature in Fahrenheit
        #temp = (bme.read_temperature()/100) * (9/5) + 32
        #temp = str(round(temp, 2)) + 'F'
        print('Temperatura: ', temp)
        print('Humedad: ', hum)
        print('Presion: ', pres)
        #temperatura = "Temp:%.01f" % temp + "c"
        display.set_line(0)
        display.set_string("Temperatura:" + temp)
        display.set_line(1)
        display.set_string("Humedad:" + hum)
        display.set_line(2)
        display.set_string("Presion:" + pres)
        display.set_line(3)
        display.set_string("   www.firtec.ar")
        sleep(5)
if __name__ == '__main__':
    main()