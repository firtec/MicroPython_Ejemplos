import machine
sda=machine.Pin(8)
scl=machine.Pin(9)
i2c=machine.I2C(0,sda=sda, scl=scl, freq=400000)
 
print('Scan bus I2C...')
devices = i2c.scan()
 
if len(devices) == 0:
  print("No existen dispositivos I2C !")
else:
  print('Dispositivos I2C encontrados:',len(devices))
 
  for device in devices:  
    print("Decimal address: ",device," | Hexa address: ",hex(device))