import machine
import utime
import _thread
import gc
# Configuramos el pin del led interno como salida y lo
# asignamos a interna_led
internal_led = machine.Pin(25, machine.Pin.OUT)
# Creamos un semáforo (también llamado bloqueo)
baton = _thread.allocate_lock()
# Función que bloqueará el hilo con un loop while
# el cual simplemente mostrará un mensaje cada segundo
def second_thread():
    while True:
        # Adquirimos el bloqueo del semáforo
        baton.acquire()
        print("Estoy en el segundo hilo escribiendo cada segundo")
        utime.sleep(1)
        # Liberamos el bloqueo del semáforo
        baton.release()
# Función que inicializa la ejecución en el segundo núcleo
# El segundo argumento es una lista o diccionario con los argumentos
# que se pasarán a la función.
_thread.start_new_thread(second_thread, ())
# Segundo loop que bloqueará el hilo principal, y que hará
# que el led interno parpadee cada medio segundo
while True:
    gc.collect()    # Limpiar posible basura en memoria
    # Adquirimos el bloqueo del semáforo
    baton.acquire()
    internal_led.toggle()
    utime.sleep(0.25)
    # Liberamos el bloqueo del semáforo
    baton.release()