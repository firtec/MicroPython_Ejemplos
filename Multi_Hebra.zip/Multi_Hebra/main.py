import machine
import utime
import _thread
# Configuramos el pin del led interno como salida y lo
# asignamos a interna_led
internal_led = machine.Pin(25, machine.Pin.OUT)
# Función que bloqueará el hilo con un loop while
# el cual simplemente mostrará un mensaje cada segundo
def second_hilo():
    while True:
        print("Estoy en el segundo hilo escribiendo cada segundo")
        utime.sleep(1)
# Función que inicializa la ejecución en el segundo núcleo
# El segundo argumento es una lista o diccionario con los argumentos
# que se pasarán a la función.
_thread.start_new_thread(second_hilo, ())
# Segundo loop que bloqueará el hilo principal, y que hará
# que el led interno parpadee cada medio segundo
while True:
    internal_led.toggle()
    utime.sleep(0.25)