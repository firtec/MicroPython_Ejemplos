import machine
import utime
import _thread
led1 = machine.Pin(16, machine.Pin.OUT)
led2 = machine.Pin(15, machine.Pin.OUT)

semaforo = _thread.allocate_lock()
def Nuevo_Hilo():
    while True:
        semaforo.acquire()
        print("Estoy en el segundo Hilo")
        utime.sleep(1)
        led2.high()
        print("Led 2 encendido")
        utime.sleep(2)
        led2.low()
        print("Led 2 apagado")
        utime.sleep(1)
        print("Estoy saliendo del segundo Hilo")
        utime.sleep(1)
        semaforo.release()
_thread.start_new_thread(Nuevo_Hilo,())
while True:
    # Activamos el semaforo
    semaforo.acquire()
    print("Estoy en el Hilo principal")
    led1.toggle()
    utime.sleep(0.50)
    print("Led 1 cambia de estado")
    utime.sleep(1)
    print("Salgo del Hilo principal")
    utime.sleep(1)
    # Liberamos el semaforo
    semaforo.release()