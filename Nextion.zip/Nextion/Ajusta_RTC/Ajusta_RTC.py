from machine import UART, Pin
from rp2 import PIO, StateMachine, asm_pio
import time
import os

BAUDIOS = 9600

HARD_UART_TX_PIN = Pin(4, Pin.OUT)
PIO_RX_PIN = Pin(3, Pin.IN, Pin.PULL_UP)

@asm_pio(in_shiftdir=rp2.PIO.SHIFT_RIGHT,)

def uart_rx():
    label("inicio")
    wait(0, pin, 0) # Espera por el bit de inicio (pin a nivel bajo el tiempo de un bit)
    # Carga el registro x con la cantidad de bits desde el primer bit de datos y espera
    # 10 cilos + wait + set 12 ciclos. (12*13uS = 156uS)
    set(x, 7)                 [10]
    label("bit_bucle")
    in_(pins, 1)  # Desplaza un bit desde el pin 3 RX al registro de desplazamiento
    # Cada bucle toma 8 ciclos, 6 + dec + jmp = 8 (8*13uS = 104uS)
    jmp(x_dec, "bit_bucle")     [6]
    jmp(pin, "terminado")  # Si el pin esta a nivel alto llegó el bit de STOP

    irq(block, 4) # Coloca bandera para informar el error.
    wait(1, pin, 0) # Espera que el pin de datos este bajo
    jmp("inicio") # No hacer nada y volver al inicio porque a ocurrido un error
    label("terminado")  # Todo ha salido bien y se ha recibido un caracter!!
    push(block)

# El handler para informar un error en la ventana de tiempos.
def error(sm):
    print("ERROR de tiempo", end="!!!")

sm = StateMachine(
    0,
    uart_rx,             # Programa que se carga en la maquina
    freq=8 * BAUDIOS,    # Frecuencia de reloj 8*9600=76800 Hz(13uS)
    in_base=PIO_RX_PIN,  # Define el pin de entrada al registro de desplazamiento
    jmp_pin=PIO_RX_PIN,  # Cuando este pin este a nivel alto saltar
    )

sm.irq(error)
sm.active(1)
cont = 0


uart = UART(0, baudrate=9600, tx=Pin(0), rx=Pin(1),timeout=10)

led = Pin(25, Pin.OUT)
led.value(0) 
bandera = 0
_year = 0
_mes = 0
_dia = 0
_hora = 0
_minutos = 0
_segundos = 0

#---------------------------------------------------------
def enviar(cmd):
     uart.write(cmd)
     uart.write(b'\xFF\xFF\xFF')
     #time.sleep_ms(100)
     #print("Response:", uart.read()) #Si habilita NO FUNCIONA EL CONVERSOR!!!!
#---------------------------------------------------------     

def main():
    
    """
    enviar("rtc0=2022")
    enviar("rtc1=1")
    enviar("rtc2=5")
    enviar("rtc3=14")
    enviar("rtc4=55")
    enviar("rtc5=0")
    """
    #enviar("page 0")
    #n0.val=rtc0
    
    #enviar("page 0")
    while True:
        global cont
        rx = sm.get() >> 24
        if cont == 0:
            a = rx
        elif cont == 1:
            enviar("rtc1="+ str(rx))
            #enviar("rtc1=rx")
            #mes = rx
        
        elif cont == 2:
            enviar("rtc2="+ str(rx))
            #enviar("rtc2=\""+ str(rx) +"\"")
            #print(str(rx))
        elif cont == 3:
            enviar("rtc3="+ str(rx))
            #hora = rx
        elif cont == 4:
            enviar("rtc4="+ str(rx))
            #minutos = rx
        elif cont == 5:
            enviar("rtc5="+ str(rx))
            #segundos = rx
        cont += 1
        if cont == 6:
            cont = 0
             
        
#Entry Point
if __name__ == '__main__':
    main()



