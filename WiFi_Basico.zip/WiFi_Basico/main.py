
import network
import utime
ap_if = network.WLAN(network.AP_IF)
ap_if.active(False)
sta_if = network.WLAN(network.STA_IF)
if not sta_if.isconnected():
        print('Conectado con la red WiFi...')
        sta_if.active(True)
        #sta_if.connect('RED1','')
        sta_if.connect('RED1', 'boricua')
        while not sta_if.isconnected():
            pass
#print('network config:', sta_if.ifconfig())
print(sta_if.ifconfig()[0])
while True:
    pass
    pass
