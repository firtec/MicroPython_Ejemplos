import time
from machine import Pin
from rp2 import PIO, StateMachine, asm_pio


PIO_boton = Pin(16, Pin.IN, Pin.PULL_UP)
conta = 0

@asm_pio()

def boton():
    label("repetir")
    wait(0, pin, 0)  [10]# Espera por el pin 16 pase a cero luego espera 5mS
    jmp(pin, "repetir")  # Si el pin es "1" repetir
	irq(block, 0) # Coloca bandera
    wait(1, pin, 0)  [10]
    

def contador(sm):
    global conta
    conta += 1
    print(conta)

sm = StateMachine(0,boton,2000,in_base=PIO_boton)

sm.irq(contador)
sm.active(1)
