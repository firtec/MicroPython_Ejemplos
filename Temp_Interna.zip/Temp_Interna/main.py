from machine import ADC
from utime import sleep
def main():    
    sensor_temp = ADC(4) #Sensor interno de temperatura
    escalado = 3.3 / (65535)
    
    while True:        
        voltaje = sensor_temp.read_u16() * escalado
        temperatura = 27 - (voltaje - 0.706)/0.001721
        print(temperatura)
        sleep(2)
        
    
if __name__ == '__main__':
    main()
