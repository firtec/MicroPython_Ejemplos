#******************************************************************************************
# Descripción : Tres sensores DS18B20 en el pin (GP_16) y muestra los datos en pantalla LCD
# Target :      Raspberry Pi PICO + DS18B20x3 + Hitachi 44780
# ToolChain :   MicroPython
# www.firtec.com.ar
#*******************************************************************************************
from machine import Pin
import machine, onewire, ds18x20, time
from time import sleep
import utime
import lcd_44780  # Importa el driver para la pantalla

def main():
    # Pines usados por la pantalla LCD
    display_pines = [2, 3, 4, 5, 6, 7]
    # Nombre de los pines del LCD (NO CAMBIARLOS)
    nombre_pines = ['RS','E','D4','D5','D6','D7']
    caracteres = 20  # Cantidad de caracteres del LCD en uso
    # Pasa los datos al modulo de control para la pantalla
    display = lcd_44780.LCD(display_pines,nombre_pines, caracteres )
    display.init() # Configura el inicio de la pantalla
    
    display.set_line(0)
    display.set_string("--------------------")
    display.set_line(1)
    display.set_string("--------------------")
    display.set_line(2)
    display.set_string("--------------------")
    display.set_line(3)
    display.set_string("--------------------")
    
    ds_pin = machine.Pin(16) # GPIO_16 Pin 21 en la placa
    ds_sensor = ds18x20.DS18X20(onewire.OneWire(ds_pin))
    roms = ds_sensor.scan()
    #print('Econtrado dispositivo ds18x20 ',  roms)  
    
    while True:    
        ds_sensor.convert_temp()
        time.sleep_ms(750)
        bandera = 0
        for rom in roms:
            sensor = ds_sensor.read_temp(rom)
            if bandera == 0:
                sensor1 = sensor
                bandera += 1
            elif bandera == 1:
                sensor2 = sensor
                bandera += 1
            elif bandera == 2:
                sensor3 = sensor
                bandera = 0    
        
        datos = "%.01f" % sensor1   # Formato para el LCD
        display.set_line(0)
        display.set_string("Sensor_1: " + datos)

        datos = "%.01f" % sensor2
        display.set_line(1)
        display.set_string("Sensor_2: " + datos)
        
        datos = "%.01f" % sensor3
        display.set_line(2)
        display.set_string("Sensor_3: " + datos)
        """
        display.set_line(2)
        display.set_string("Temperatura:" + datos)
        """
        display.set_line(3)
        display.set_string("   www.firtec.ar")
        
if __name__ == '__main__':
    main()