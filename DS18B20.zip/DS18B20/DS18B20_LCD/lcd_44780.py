#***********************************************************************************************
# Descripción : Modulo de control para display LCD basado en hitachi 44780 
# ToolChain :   MicroPython
# www.firtec.com.ar
#***********************************************************************************************
from machine import Pin, Timer
import utime

class LCD(object):
     def __init__(self, Pines, Nombre_pines, caracteres):
         self.Pines = Pines
         self.Nombre_pines = Nombre_pines
         self.caracteres = caracteres
         self.pins = {} # Diccionario de pines
         # Utilizado para poner los pines en modo salida
         self.PIN_MODE = Pin.OUT
         self.LCD_WIDTH = caracteres # LCD 2004 tiene 20 caracteres por 4 lineas
         # Control comando/mensaje
         self.LCD_CHR = True
         self.LCD_CMD = False
         self.LINES = {
             0: 0x80, # LCD RAM dirección para la primer linea
             1: 0xC0, # LCD RAM dirección para la segunda linea
             2: 0x94, # LCD RAM dirección para la tercer linea
             3: 0xD4  # LCD RAM dirección para la cuarta linea
         }
    # Costante para el control de tiempos
         self.E_PULSE = 1
         self.E_DELAY = 1

     def init(self):  
         for pin, pin_name in zip(self.Pines, self.Nombre_pines):
            self.pins['LCD_'+pin_name] = Pin(pin, self.PIN_MODE)  
        # Configuración inicial del display
         self.lcd_byte(0x33,self.LCD_CMD)
         self.lcd_byte(0x32,self.LCD_CMD)
         self.lcd_byte(0x28,self.LCD_CMD)
         self.lcd_byte(0x0C,self.LCD_CMD)
         self.lcd_byte(0x06,self.LCD_CMD)
         self.lcd_byte(0x01,self.LCD_CMD)  
     
     def clear(self): # Función para limpiar la pantalla
          self.lcd_byte(0x01,self.LCD_CMD)

     def set_line(self, line): # Configura la línea donde escribir
         self.lcd_byte(self.LINES[line], self.LCD_CMD)

     def set_string(self, message): # Escribe una cadena en pantalla
         m_length = len(message)
         if m_length < self.LCD_WIDTH:
             short = self.LCD_WIDTH - m_length
             blanks=str()
             for i in range(short):
                 blanks+=' '
             message+=blanks
         for i in range(self.LCD_WIDTH):
             self.lcd_byte(ord(message[i]), self.LCD_CHR)

     def lcd_byte(self, bits, mode): # Envía un byte a la pantalla
        self.pin_action('LCD_RS', mode) # Cambia estado de pin RS
        # Parte alta de los bits
        self.pin_action('LCD_D4', False)
        self.pin_action('LCD_D5', False)
        self.pin_action('LCD_D6', False)
        self.pin_action('LCD_D7', False)
        if bits&0x10==0x10:
            self.pin_action('LCD_D4', True)
        if bits&0x20==0x20:
            self.pin_action('LCD_D5', True)
        if bits&0x40==0x40:
            self.pin_action('LCD_D6', True)
        if bits&0x80==0x80:
            self.pin_action('LCD_D7', True)

        # Cambia el estado del pin 'Enable'
        self.udelay(self.E_DELAY)
        self.pin_action('LCD_E', True)
        self.udelay(self.E_PULSE)
        self.pin_action('LCD_E', False)
        self.udelay(self.E_DELAY)

        # Parte baja de los bits
        self.pin_action('LCD_D4', False)
        self.pin_action('LCD_D5', False)
        self.pin_action('LCD_D6', False)
        self.pin_action('LCD_D7', False)
        if bits&0x01==0x01:
            self.pin_action('LCD_D4', True)
        if bits&0x02==0x02:
            self.pin_action('LCD_D5', True)
        if bits&0x04==0x04:
            self.pin_action('LCD_D6', True)
        if bits&0x08==0x08:
            self.pin_action('LCD_D7', True)

        # Cambia el estado del pin 'Enable'
        self.udelay(self.E_DELAY)
        self.pin_action('LCD_E', True)
        self.udelay(self.E_PULSE)
        self.pin_action('LCD_E', False)
        self.udelay(self.E_DELAY)
        
     def udelay(self, us): # Epera microsegundos
         utime.sleep_ms(us)

     def pin_action(self, pin, high): # Cambia estado de pines (alto/bajo)
        
        if high:
            self.pins[pin].value(1)
        else:
            self.pins[pin].value(0)