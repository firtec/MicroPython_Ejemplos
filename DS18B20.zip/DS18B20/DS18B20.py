import machine, onewire, ds18x20, time
 
ds_pin = machine.Pin(16) # GPIO_16 Pin 21 en la placa
ds_sensor = ds18x20.DS18X20(onewire.OneWire(ds_pin))
 
roms = ds_sensor.scan()
print('Econtrado dispositivo ds18x20 ',  roms)
 
while True:
  ds_sensor.convert_temp()
  time.sleep_ms(750)
  for rom in roms:
    Va = ds_sensor.read_temp(rom)  
    datos = "%.01f" % Va   # Formato para el LCD
    print(rom)
    print('Temperatura: {0}'.format(datos))   # Pasa el dato a la terminal de Thonny
  #time.sleep(2)