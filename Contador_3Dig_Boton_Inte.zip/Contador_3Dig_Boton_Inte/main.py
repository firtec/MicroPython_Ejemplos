from machine import Pin, Timer
import utime
import display7seg

def ISR_11(p):
         global contador
         contador += 1

boton = Pin(11, Pin.IN, Pin.PULL_UP)
boton.irq(trigger=Pin.IRQ_FALLING, handler= ISR_11)

def main():
    global contador
    T1 = Pin(22, Pin.OUT)
    T1.value(0) 
    T2 = Pin(21, Pin.OUT)
    T2.value(0) 
    T3 = Pin(20, Pin.OUT)
    T3.value(0)
    
    display_pines = (16, 18, 13, 14, 15, 17, 12) #(a, b, c, d, e, f, g)
    
    contador = 0   
    while True:
        if(contador < 9):  
            transistor_pines = [ 22]   # Solo activar la unidad
            display7 = display7seg.Display(display_pines,transistor_pines = transistor_pines )
        elif((contador > 9) and (contador < 99)):
            transistor_pines = [ 22,21]  # Activar la unidad y decena
            display7 = display7seg.Display(display_pines,transistor_pines = transistor_pines )
        elif(contador > 99):
            transistor_pines = [ 22,21,20] # Activar unidad, decena y centena
            display7 = display7seg.Display(display_pines,transistor_pines = transistor_pines )    
        
        display7.Mostrar(contador)      #Llamar la rutina MOSTRAR
        
if __name__ == '__main__':
    main()