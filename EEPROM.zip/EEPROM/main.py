#------- Memoria bajo prueba 24LC256 ----------

from machine import Pin, I2C
#from time import sleep
from time import sleep_ms
from machine import I2C
import utime

# Define the i2c interface on pins 1 and 2. Ground is taken from pin 3 and 3.3v from pin 36 (3V3(OUT))
sda = machine.Pin(0)  # GP_0
scl = machine.Pin(1)  # GP_1

I2C_BUS = machine.I2C(0, sda=sda, scl=scl, freq=400000)
#i2c = I2C(scl=Pin(5), sda=Pin(4), freq=400000)

devices = I2C_BUS.scan()
if devices:
    for i in devices:
        print("Dir:",i)

#adress_stock = 0x7D00
adress_stock = 0xE0 
print("Adress R/W : ", adress_stock)

# Is there something before I try to write ?
print("Estado Anterior : ", I2C_BUS.readfrom_mem(80, adress_stock, 4, addrsize=16 ) )
sleep_ms(10)

# Try to write '0x1234' in the memory at 0x10 adress
val = b'Hola Firtec'
print("Se ha escrito : ", val )
I2C_BUS.writeto_mem(80, adress_stock, val, addrsize=16)
sleep_ms(10)

# Does the memory received and stocked the information ?
print("Se lee en memoria : ", I2C_BUS.readfrom_mem(80, adress_stock, 11, addrsize=16) )
