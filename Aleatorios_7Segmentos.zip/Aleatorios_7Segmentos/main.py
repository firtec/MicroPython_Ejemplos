from machine import Pin, Timer
from machine import ADC
import time
import display7seg
import urandom

def ISR_Tim(p):
    global bandera
    bandera = 1

def ISR_11(p):
         global bandera_0
         bandera_0 = 1    
       
def main():
    global led
    led = Pin(25, Pin.OUT)   
    led.value(0)
    boton = Pin(11, Pin.IN, Pin.PULL_UP)
    boton.irq(trigger=Pin.IRQ_FALLING, handler= ISR_11)
    global bandera
    global bandera_0
    global conversor
    bandera = 0
    bandera_0 = 0
    aleatorio = 0
    
    tim = Timer()  
    tim.init(freq=10, mode=Timer.PERIODIC, callback=ISR_Tim) # Crea la interrupcion
    # Todos los transistores inician desactivados!!
    T1 = Pin(22, Pin.OUT)
    T1.value(0) 
    T2 = Pin(21, Pin.OUT)
    T2.value(0) 
    T3 = Pin(20, Pin.OUT)
    T3.value(0)
    ad = ADC(0) # Canal ADC en pin 26 
   
    display_pines = [16, 18, 13, 14, 15, 17, 12] 
    transistor_pines = (22, 21, 20)
    display7 = display7seg.Display(display_pines,transistor_pines = transistor_pines )
            
    while True: 
        if (bandera == 1):
           
            conversor= ad.read_u16()
            
            bandera = 0
        if (bandera_0 == 1):
            a = urandom.getrandbits(16)
            aleatorio = (conversor and a)
            
            bandera_0 = 0
        display7.Mostrar(int (aleatorio)) 

if __name__ == '__main__':
    main()