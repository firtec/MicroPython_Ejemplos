#****************************************************************************************
# Descripción : Ejemplo de uso para una pantalla Hitachi 44780 
# Target :      Raspberry Pi PICO
# ToolChain :   MicroPython
# www.firtec.com.ar
#***************************************************************************************
from machine import Pin, Timer
import utime
import lcd_44780  # Importa el driver para la pantalla

def main():
    # Pines usados por la pantalla LCD
    display_pines = [2, 3, 4, 5, 6, 7]
    # Nombre de los pines del LCD (NO CAMBIARLOS)
    nombre_pines = ['RS','E','D4','D5','D6','D7']
    caracteres = 20  # Cantidad de caracteres del LCD en uso
    # Pasa los datos al modulo de control para la pantalla
    display = lcd_44780.LCD(display_pines,nombre_pines, caracteres )
    display.init() # Configura el inicio de la pantalla
    display.set_line(0)  # Cursor en la primera línea
    display.set_string("Hola Firtec!") # Texto a mostrar en pantalla
    display.set_line(1)  # Cursor en la segunda línea
    display.set_string("Yo soy PICO!") # Texto a mostrar en pantalla
    display.set_line(2)  # Cursor en la tercera línea
    display.set_string("Y estoy funcionando!") # Texto a mostrar en pantalla
    display.set_line(3)  # Cursor en la cuarta línea
    display.set_string("www.firtec.com.ar") # Texto a mostrar en pantalla
    
if __name__ == '__main__':
    main()