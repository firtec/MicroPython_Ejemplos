from machine import UART, Pin
from machine import I2C
import DS3231
import time
import os
sda = machine.Pin(18)  # Pines asignados al I2C
scl = machine.Pin(19)  

i2c = machine.I2C(1, sda=sda, scl=scl, freq=100000)
ds = DS3231.DS3231(i2c)

#ds.DateTime([2021,5,13,1,17,24,0])
ds.Hour()
ds.Time()

puerto = UART(0, baudrate=9600, tx=Pin(0), rx=Pin(1),timeout=1)
cont = 0

while(1): 
    while puerto.any() > 0:  # Recibe los datos desde el soft de ajuste 
            datos = puerto.read(1).decode('utf-8')
            rx = "".join(hex(ord(n)) for n in datos)
            if cont == 0:
                year = rx
                year = int(year,16)  # Acondiciona el año
            elif cont == 1:
                mes = rx
                mes = int(mes,16)    # Acondiciona el mes
            elif cont == 2:
                dia = rx
                dia = int(dia,16)    # Acondiciona el día
            elif cont == 3:
                hora = rx
                hora = int(hora,16)  # Acondiciona la hora
            elif cont == 4:
                minutos = rx
                minutos = int(minutos,16)   # Acondiciona los minutos
            elif cont == 5:
                segundos = rx
                segundos = int(segundos,16) # Acondiciona los segundos
            cont += 1
            if cont == 6:
                ds.DateTime([year,mes,dia,1,hora,minutos,segundos])  # Ajuste del calendario
                """
                print(year)
                print(mes)
                print(dia)
                print(hora)
                print(minutos)
                print(segundos)
                """
                cont = 0
    
    #print(ds.Temperature())
    b = ds.Date()
    a = ds.Time()
    print(b[2],b[1],b[0])

    print(a[0],a[1],a[2])
    time.sleep_ms(800)          