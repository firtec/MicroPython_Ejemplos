import utime
try:
  import usocket as socket
except:
  import socket
 
from time import sleep
from machine import Pin
import network
 
import esp
esp.osdebug(None)
 
import gc
gc.collect()    # Limpiar posible basura en memoria
 
ssid = 'RED1'
password = 'boricua'
 
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect(ssid, password)
while not wifi.isconnected():
    print(".")
    utime.sleep(1)
print("IP asignada: " + wifi.ifconfig()[0])

led = Pin(5, Pin.OUT)


  
def web_page():
    
    if led.value() == 1:
        pin_estado ="SI"
    else:
        pin_estado ="NO"

    html = """<html><head><title>Micropython & ESP32</title><body style=background:#F0FFFF>
      <h1>Control de un pin con ESP32</h1>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" href="data:,"> <style>html{font-family: Helvetica; display:inline-block; margin: 0px auto; text-align: center;}
      h1{color: #0F3376; padding: 2vh;}p{font-size: 1.5rem;}.button{display: inline-block; background-color: #e7bd3b; border: none; 
      border-radius: 4px; color: white; padding: 16px 40px; text-decoration: none; font-size: 30px; margin: 2px; cursor: pointer;}
      .button2{background-color: #4286f4;}</style></head><body> 
      <p>Estado del Pin: <strong>""" + pin_estado + """</strong></p><p><a href="/?led=si">
      <button class="button">Encendido</button></a></p>
      <p><a href="/?led=no"><button class="button button2">Apagado</button></a></p></body></html>
      <br>
      <hr Size=7 noshade/><H5><font color='black'>by. Firtec Argentina </H5> 
      """
    return html
# --------------- Crea el socket TCP-IP --------------
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('', 80)) # Crea socket seervidor que escucha en puerto 80
s.listen(5)      # Admite hasta 5 solicitudes
#-----------------------------------------------------

while True:
  if gc.mem_free() < 102000:  # Si la memoria es menos de 102000
      gc.collect()              # Limpiar basura 
  conexion, addr = s.accept()
  mensaje = conexion.recv(1024)
  mensaje = str(mensaje)
  
  led_si = mensaje.find('/?led=si')
  led_no = mensaje.find('/?led=no')
 
  if led_si == 6:   # 6 es el indice donde se encuentra led=si
    print('LED SI')
    led.value(1)
  if led_no == 6:
    print('LED NO')
    led.value(0)
  respuesta = web_page()
  conexion.send('HTTP/1.1 200 OK\n')
  conexion.send('Content-Type: text/html\n')
  conexion.send('Connection: close\n\n')
  conexion.sendall(respuesta)
  conexion.close()