import time                     # Para las pausas
from machine import Pin
import utime

pinDir = Pin(16, Pin.OUT)
pinDir.value(0) 
pinStep = Pin(17, Pin.OUT)
pinStep.value(0) 

numSteps = 220                  #Número de pasos del motor
microPausa = 0.003              #Número de segundos de pausa

while True:

        pinDir.value(0)
        for x in range(0,numSteps):
                pinStep.value(1)
                time.sleep(microPausa)
                pinStep.value(0)
                time.sleep(microPausa)

        time.sleep(microPausa)        
        pinDir.value(1)  # Cambio de dirección

        for x in range(0,numSteps):
                pinStep.value(1)
                time.sleep(microPausa)
                pinStep.value(0)
                time.sleep(microPausa)

GPIO.cleanup()          # Para acabar correctamente