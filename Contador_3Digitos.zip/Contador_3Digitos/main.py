from machine import Pin, Timer
import utime
import display7seg

def temporizador(timer):
    #Variables globales compartidas con el main
    global contador, sentido
    #Lógica de la interrupción
    if sentido:
        contador += 1
    else:
        contador -= 1
        
def main():
    # Todos los transistores inician desactivados!!
    T1 = Pin(22, Pin.OUT)
    T1.value(0) 
    T2 = Pin(21, Pin.OUT)
    T2.value(0) 
    T3 = Pin(20, Pin.OUT)
    T3.value(0) 
    global contador, sentido
    
    display_pines = [16, 18, 13, 14, 15, 17, 12] #(a, b, c, d, e, f, g)
    #Inicia las variables
    contador = 0
    sentido = True
    
    tim = Timer()
    tim.init(period= 200, mode=Timer.PERIODIC, callback=temporizador)
    
    while True:
        if(contador < 0x0F):  
            transistor_pines = [ 22]   # Solo activar la unidad
            display7 = display7seg.Display(display_pines,transistor_pines = transistor_pines )
        elif((contador > 0x0F) and (contador < 0xff)):
            transistor_pines = [ 22,21]  # Activar la unidad y decena
            display7 = display7seg.Display(display_pines,transistor_pines = transistor_pines )
        elif(contador > 0xFF):
            transistor_pines = [ 22,21,20] # Activar unidad, decena y centena
            display7 = display7seg.Display(display_pines,transistor_pines = transistor_pines )    
        
        display7.Mostrar(contador)      #Llamar la rutina MOSTRAR        
        #Si contador es 0XFFF coloque el sentido del contador a decrementar
        if contador == 0xFFF:
            sentido = False
        
        #Si contador es cero coloque el sentido del contador a incrementar
        if contador == 0:
            sentido = True

if __name__ == '__main__':
    main()
    T1 = Pin(22)
    T1.value(0) 
    T2 = Pin(21)
    T2.value(0) 
    T3 = Pin(20)
    T3.value(0)