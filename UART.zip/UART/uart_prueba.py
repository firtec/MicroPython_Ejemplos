from machine import UART, Pin
import time
import os


#uart1 = UART(1, baudrate=9600, tx=Pin(8), rx=Pin(9))

uart0 = UART(0, baudrate=9600, tx=Pin(0), rx=Pin(1))

rxData = bytes()
print(os.uname())

while(1):
    while uart0.any() > 0:
        rxData = uart0.read(13)
        uart0.write(rxData)
        print(rxData.decode('utf-8'))
