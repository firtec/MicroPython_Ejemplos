# =========================================================================
# - Conectando con MicroPython
# - Uso de la biblioteca pyserial para recibir datos del conversor A/D
# - Firtec Argentina
# - www.firtec.com.ar
# ==========================================================================

# -*- coding: utf-8 -*-
#!/usr/bin/env python

import serial
from tkinter import Label
from tkinter import *
import time
puerto = serial.Serial('COM9', 9600, timeout=.1)
#dato_Micropython
#global dato_Micropython

class Aplicacion:
        def __init__(self):
            global ventana
            ventana = Tk()
            ventana.iconbitmap('11.ICO')
            ventana.title(" Voltimetro UART")      
            ventana.config(bg="coral") # Le da color al fondo
            ventana.geometry("330x150") # Cambia el tamaño de la ventana
            ventana.resizable(0,0) # Evita que se le pueda cambiar de tamaño a la ventana
            ventana.label_1 = Label(ventana, text="Voltios: 0.0", bg="coral", fg="black", font=("Helvetica", 40))
            ventana.label_1.place(x=14, y=30)
            ventana.label = Label(ventana, text="0", bg="coral", fg="black", font=("Helvetica", 40))
            ventana.label.place(x=200, y=30)
            receptor_serial()
            ventana.mainloop()          

def receptor_serial():
        
        try:
                dato_MicroPython = (puerto.readline()) 
                ventana.label.config(text= dato_MicroPython.decode())
                puerto.flushInput()
                ventana.after(500, receptor_serial)
       
        except puerto.SerialException:
                print("ERROR de comunicación")
                puerto.flushInput()
                raise
               

def main():
    mi_app = Aplicacion()
    return 0

if __name__ == '__main__':
    main()
        
