from machine import UART, Pin
import time
import os
from machine import ADC


uart0 = UART(0, baudrate=9600, tx=Pin(0), rx=Pin(1))
datos_tx = bytes()


def main():
    potenciometro = machine.ADC(26) # Canal ADC en pin 26
    factor_16 = 3.3 / (65535)   
    while True:
        global Hi
        bits_16 = potenciometro.read_u16()
        volts_16 = bits_16 * factor_16
        datos_tx = "%.02f \n" % (volts_16)
        uart0.write(datos_tx)
        print('Voltios: {}'.format(datos_tx))
        time.sleep(0.5)
        
#Entry Point
if __name__ == '__main__':
    main()
