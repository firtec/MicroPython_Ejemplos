
from machine import Pin, SPI
import sdcard
import os


# Pines usados por la memoria SD
# SD   | GP
# ----------
# SCK  | 10
# MOSI | 11
# MISO | 12
# CS   | 15
# ----------
sd_spi = SPI(1, sck = Pin(10, Pin.OUT), mosi = Pin(11, Pin.OUT),miso = Pin(12, Pin.OUT))
# Crea el objeto sd
sd = sdcard.SDCard(sd_spi, Pin(15, Pin.OUT))
vfs = os.VfsFat(sd)
os.mount(vfs, "/fc") # Monta el sistema de archivos
print("Carpetas en memoria:")
print(os.listdir("/fc"))

linea1 = "Hola Firtec\n"
linea2 = "1234567890\n"

fn = "/fc/archivo1.txt"
print()
print("Multiples bloques de Lectura/Escritura")
with open(fn, "w") as f:
    n = f.write(linea1)
with open(fn, "r") as f:
    result1 = f.read()
    #print(len(result1), "bytes leidos")
    print("\nPrimera Lectura:", result1)

fn = "/fc/archivo2.txt"
with open(fn, "w") as f:
    n = f.write(linea2) 
with open(fn, "r") as f:
    result2 = f.read()
    print("Segunda Lectura:",result2 )

os.umount("/fc") # Desmonta el sistema de archivos
