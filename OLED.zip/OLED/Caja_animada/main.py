from machine import Pin, I2C
import sh1106
import utime

i2c = I2C(0, sda=Pin(21), scl=Pin(22), freq=400000)
display = sh1106.SH1106_I2C(128, 64, i2c, Pin(4), 0x3c)
display.sleep(False)
display.fill(0) 
display.text('Carga datos..', 0, 0, 1) 
display.hline(0, 9, 127, 1)
display.hline(0, 30, 127, 1)
display.vline(0, 10, 32, 1)
display.vline(127, 10, 32, 1)

for i in range(0, 118): 
    display.fill_rect(i,10, 10, 10, 1)  
    display.fill_rect(10, 21, 30, 8, 0)
    display.text(str(i), 10, 21, 1)
    display.show()
    # utime.sleep(0.001)
print('Terminado')