from machine import Pin, I2C
import sh1106
import utime

i2c = I2C(0, sda=Pin(21), scl=Pin(22), freq=400000)
display = sh1106.SH1106_I2C(128, 64, i2c, Pin(4), 0x3c)
display.sleep(False)
display.fill(0)
display.text('Firtec', 0, 0, 1)
display.show()
print('Terminado')
