from machine import Pin, I2C
import sh1106
import utime

width=128
height=64
i2c = I2C(0, sda=Pin(21), scl=Pin(22), freq=400000)

oled = sh1106.SH1106_I2C(128, 64, i2c, Pin(4), 0x3c)
oled.sleep(False)

oled.fill(0) 

def border(width, height):
    oled.hline(0, 0, width - 1, 1) 
    oled.hline(0, height - 2, width - 1, 1) 
    oled.vline(0, 0, height - 1, 1) 
    oled.vline(width - 1, 0, height - 1, 1) 


def draw_ball(x,y, size, state):
    if size == 1:
        oled.pixel(x, y, state) 
    else:
        for i in range(0,size): 
            for j in range(0,size):
                oled.pixel(x + i, y + j, state)
    

border(width, height)

ball_size = 5
current_x = int(width / 2)
current_y = int(height / 2)
direction_x = 1
direction_y = -1
# delay_time = .0001


while True:
    draw_ball(current_x,current_y, ball_size,1)
    oled.show()
    # utime.sleep(delay_time)
    draw_ball(current_x,current_y,ball_size,0)
    
    if current_x < 2:
        direction_x = 1
    
    if current_x > width - ball_size -2:
        direction_x = -1
    
    if current_y < 2:
        direction_y = 1
    
    if current_y > height - ball_size - 3:
        direction_y = -1
   
    current_x = current_x + direction_x
    current_y = current_y + direction_y


print('done')