import machine
import time
import rp2


@rp2.asm_pio(set_init=rp2.PIO.OUT_LOW)
def led_no():
    set(pins, 0)

@rp2.asm_pio(set_init=rp2.PIO.OUT_LOW)
def led_si():
    set(pins, 1)

maquina1 = rp2.StateMachine(1, led_no, freq=2050, set_base=machine.Pin(25))
maquina2 = rp2.StateMachine(2, led_si, freq=2045, set_base=machine.Pin(25))

maquina1.active(1)
maquina2.active(1)
