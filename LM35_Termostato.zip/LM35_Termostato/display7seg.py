"""
Clase de Display 7 Segmentos usando MicroPython
Display tipo Cátodo comúm
Puede mostrar números hexadecimales de 0 a F
"""
from machine import Pin
import utime
class Display:

    def __init__(self, Pins, transistor_pines = 1):
        self.numero_de_digitos = len(transistor_pines)
        
        #Configura los pines del display como salida
        display = list()
        for i in range(7):
            display.append( Pin(Pins[i], Pin.OUT) )
        
        #Configura los pines de los transistores como salida
        transistores = list()
        
        for i in range(self.numero_de_digitos):
            transistores.append( Pin(transistor_pines[i], Pin.OUT) )
        
        #Tupla con las posiciones del display
        self.display = display
        
        #Tupla con las posiciones de los transistores
        self.transistores = transistores
#------------------------------------------------------        
    def Mostrar(self, digitos):
        #Realiza la multiplexación
        for i in range( self.numero_de_digitos ): # Base hexadecimal
            dato = int((digitos % 10 ** (i+1)) / 10 ** i)
            self._Mostrar_un_Display(dato)  # Activa los segmentos
            self.transistores[i].on()  # Activa el digito
            utime.sleep_ms(4)
            self.transistores[i].off() # Apaga el digito      
#-------------------------------------------------------    
    #Metodo provado para mostrar número en un solo display
    def _Mostrar_un_Display(self, dato):
        bit = 1;
        # Codifica los segmentos para números hexadecimales de 0 a F
        numero = (int('3F',16),int('06',16),int('5B',16),int('4F',16),int('66',16),
            int('6D',16),int('7D',16),int('07',16),int('7F',16),int('67',16),
            int('77',16),int('7C',16),int('39',16),int('5E',16),int('79',16),int('71',16))
        
        for i in range(7):
            if (numero[dato]  & bit) == 0:
                self.display[i].off()  # Apaga segmentos
            else:
                self.display[i].on()   # Enciende segmentos
            bit = bit << 1