from machine import Pin, Timer
from machine import ADC
import time
import display7seg

def ISR(p):
    global bandera
    bandera = 1
          
def main():
    led = Pin(25, Pin.OUT)   # Pin es puesto como salida
    led.value(0)
    global bandera
    temperatura = 0
    #escala = 0
    #AD = 0
    bandera = 0
    #conversor = 0
    M0 = 0
    muestras = 0
    tim = Timer()  
    tim.init(freq=5, mode=Timer.PERIODIC, callback=ISR) # Crea la interrupcion
    # Todos los transistores inician desactivados!!
    T1 = Pin(22, Pin.OUT)
    T1.value(0) 
    T2 = Pin(21, Pin.OUT)
    T2.value(0) 
    sensor = ADC(0) # Canal ADC en pin 26 
    
    display_pines = [16, 18, 13, 14, 15, 17, 12] #(a, b, c, d, e, f, g)
    transistor_pines = [ 22,21] # Activar unidad, decena y centena
    display7 = display7seg.Display(display_pines,transistor_pines = transistor_pines ) 
        
    while True:
        display7.Mostrar(temperatura)
        if (bandera == 1):
            led.toggle()
            muestras += 1    
            M0 += sensor.read_u16()
            if(5 == muestras): 
               AD = M0/5  # Se busca el promedio de 5 muestras
               escala = (AD * 3.3) / 65535
               temperatura = escala / (10.0 / 1000)
               print ("%2u °C" % (temperatura))
               muestras = 0
               M0 = 0
            bandera = 0        
        
#Entry Point
if __name__ == '__main__':
    main()