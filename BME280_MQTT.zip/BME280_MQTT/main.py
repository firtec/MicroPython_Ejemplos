import machine
from time import sleep
import utime as time
import sys
import BME280
from umqtt.robust import MQTTClient
import network
import utime

import gc
gc.collect()    # Limpiar posible basura en memoria

sda = machine.Pin(21)  # GP_21
scl = machine.Pin(22)  # GP_22

i2c = machine.I2C(0, sda=sda, scl=scl, freq=100000)
led = machine.Pin(5,machine.Pin.OUT)
led.off()

client = MQTTClient("esp32-01", "192.168.0.80") # IP de Raspberry PI 
sta = network.WLAN(network.STA_IF)
if not sta.isconnected():
  print('Conectando con la red WiFi...')
  sta.active(True)
  sta.connect('RED1', 'boricua')
  
  while not sta.isconnected():
    pass
print("Ip asignada:",sta.ifconfig()[0])


def publish():
    while True:
        bme = BME280.BME280(i2c=i2c)
        temp = bme.temperature
        hum = bme.humidity
        pres = bme.pressure
        msg = b'{"Temperatura":%s,"Humedad":%s,"Presion":%s}' % (temp, hum, pres)
        client.publish(b"firtec/bme280", msg)
        time.sleep(20)

client.reconnect()

publish()

"""
while True:
    if gc.mem_free() < 102000:  # Si la memoria es menos de 102000
      gc.collect()              # Limpiar basura 
    bme = BME280.BME280(i2c=i2c)
    temp = bme.temperature
    hum = bme.humidity
    pres = bme.pressure
    #print('Temperatura: ', temp)
    #print('Humedad: ', hum)
    #print('Presion: ', pres)
    conexion, addr = s.accept()
    mensaje = conexion.recv(1024)
    mensaje = str(mensaje)
    consulta = mensaje.find('/leer_sensor')
    if consulta == 6:
        temp = bme.temperature
        hum = bme.humidity
        pres = bme.pressure
        respuesta = temp + "|"+ hum + "|"+ pres
        led.value(not led.value())
    else:
       respuesta = web_page()    
  
    conexion.send('HTTP/1.1 200 OK\n')
    conexion.send('Content-Type: text/html\n')
    conexion.send('Connection: close\n\n')
    conexion.sendall(respuesta)
    conexion.close()
"""