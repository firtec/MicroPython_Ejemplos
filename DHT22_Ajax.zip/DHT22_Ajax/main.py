import machine
import dht
led = machine.Pin(5,machine.Pin.OUT)
led.off()
d = dht.DHT22(machine.Pin(23))


# ************************
# Configure the ESP32 wifi
# as STAtion mode.
import network
import utime
#import wifi_credentials
#sta_if = network.WLAN(network.STA_IF)
sta = network.WLAN(network.STA_IF)
if not sta.isconnected():
  print('Conectando con la red WiFi...')
  sta.active(True)
  #sta.connect('your wifi ssid', 'your wifi password')
  sta.connect('RED1', 'boricua')
  #sta.connect(wifi_credentials.ssid, wifi_credentials.password)
  while not sta.isconnected():
    pass
print("Ip asignada:",sta.ifconfig()[0])

import socket
#------------ Crea un socket TCP (SOCK_STREAM) ---------------
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(('',80)) # Desde cualquier IP se escucha en el puerto 80
s.listen(5)     # Reconoce solo 5 socket a la vez


# *********************************
# Esta función es la encargada de
# crear la página web
#**********************************
def web_page():
    html_page = """
<!DOCTYPE html>  
 <html>  
  <head>  
  <meta name='viewport' content='width=device-width, initial-scale=1.0'/>  
  <script>   
   var ajaxRequest = new XMLHttpRequest();  
   
   function ajaxLoad(ajaxURL)  
   {  
    ajaxRequest.open('GET',ajaxURL,true);  
    ajaxRequest.onreadystatechange = function()  
    {  
     if(ajaxRequest.readyState == 4 && ajaxRequest.status==200)  
     {  
      var ajaxResult = ajaxRequest.responseText;  
      var tmpArray = ajaxResult.split("|");  
      document.getElementById('temp').innerHTML = tmpArray[0];  
      document.getElementById('hum').innerHTML = tmpArray[1];  
     }  
    }  
    ajaxRequest.send();  
   }  
     
   function leerDHT()   
   {   
     ajaxLoad('leer_sensor');   
   }  
     
   setInterval(leerDHT, 3000);  
    
  </script>  
    
    
  <title>Micropython & ESP32</title>
  </head>  
    
  <body style=background:#F5DEB3>
  <title>Micropython & ESP32</title>
   <center>  
   <div id='main'>  
    <h1>MicroPython con ESP32 y DHT22</h1>  
    <h4>Web server con ESP32 | Lectura sensor DHT22 mediante AJAX.</h4>  
    <div id='content'>   
     <p>Temperatura: <strong><span id='temp'>--.-</span> &deg;C</strong></p>  
     <p>Humedad: <strong><span id='hum'>--.-</span> % </strong></p>  
    </div>  
   </div>
    <br>
      <hr Size=7 noshade/><H5><font color='black'>by. Firtec Argentina </H5> 
   </center>  
  </body>  
 </html>
"""
    return html_page

while True:
    conn, addr = s.accept()
    request=conn.recv(1024)
    request = str(request)
    update = request.find('/leer_sensor')
    if update == 6:
        d.measure()
        t = d.temperature()
        h = d.humidity()
        response = str(t) + "|"+ str(h)
        led.value(not led.value())
    else:
        response = web_page()
        
    # Create a socket reply
    conn.send('HTTP/1.1 200 OK\n')
    conn.send('Content-Type: text/html\n')
    conn.send('Connection: close\n\n')
    conn.sendall(response)
    conn.close()

